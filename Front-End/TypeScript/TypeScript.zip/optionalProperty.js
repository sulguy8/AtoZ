var userInfo = {
    username: 'sulguy@naver.com',
    password: '123456'
};
console.log(userInfo);
