var Queue = /** @class */ (function () {
    function Queue() {
        this.data = [];
    }
    Queue.prototype.push = function (item) {
        this.data.push(item);
    };
    Queue.prototype.pop = function () {
        return "안녕";
    };
    return Queue;
}());
// number 전용 Queue
var numberQueue = new Queue();
numberQueue.push(0);
// numberQueue.push('1')  // 의도하지 않은 실수를 사전 검출 가능
numberQueue.push(+'1');
// string 전용 Queue
var stringQueue = new Queue();
stringQueue.push('Hello');
stringQueue.push('World');
console.log(stringQueue.pop().toUpperCase());
console.log(stringQueue.pop().toUpperCase());
// 커스텀 객체 전용 Queue
var myQueue = new Queue();
myQueue.push({ name: 'Lee', age: 10 });
myQueue.push({ name: 'kim', age: 20 });
console.log(myQueue.pop()); // { name: 'Lee', age: 10 }
console.log(myQueue.pop()); // { name: 'Kim', age: 20 }
// 제네릭은 선언 시점이 아니라 생성 시점에 타입을 명시하여 하나의 타입만이 다양한 타입을 사용할 수 있도록 하는 기법
// 또한 함수에도 제네릭이 사용 가능하다.
// 제네릭을 사용하면 하나의 타입만이 아닌 다양한 타입의 매개변수와 반환값을 사용할 수 있다.
function reverse(items) {
    return items.reverse();
}
// reverse 함수는 인수의 타입에 의해 타입 매개변수가 결정된다. 
// reverse 함수는 다양한 타입의 요소로 구성된 배열을 인자로 전달 받는다.
function reverse2(items) {
    return items.reverse();
}
var arg = [1, "안녕?", 3, 4, 5];
// 인수에 의해 타입 매개변수가 결정된다.
var reversed = reverse(arg);
console.log(reversed); // [5, 4, 3, 2, 1]
/*
    만약 { name: string } 타입의 요소를 갖는 배열을
    전달받으면 타입 매개변수는 { name: string }이 된다.
*/
function reverse4(items) {
    return items.reverse();
}
var arg3 = [{ name: 'Lee' }, { name: 'Kim' }];
// 인수에 의해 타입 매개변수가 결정된다.
var reversed3 = reverse4(arg3);
console.log(reversed3); // [ { name: 'Kim' }, { name : 'Lee' } ]
