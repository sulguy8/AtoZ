var num = 1;
var addNum = num + '1';
console.log(+'1');
