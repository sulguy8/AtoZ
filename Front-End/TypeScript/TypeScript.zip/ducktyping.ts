interface IDuck {
    quack(): void;
}

class MallardDuck implements IDuck {
    quack() {
        console.log("Quack!");
    }
}

class RedheadDuck {
    quack() {
        console.log('q~uack!');
    }
}

function makeNoise(duck: IDuck): void {
    duck.quack();
}

makeNoise(new MallardDuck());
makeNoise(new RedheadDuck());   // implements가 없음에도 불구하고 에러가 발생하지 않는다.

// 타입스크립트는 해당 인터페이스에서 정의한 프로퍼티나 메소드를 가지고 있다면 그 인터페이스를 구현한 것으로 인정한다.
// 이것을 '덕 타이핑' 또는 '구조적 타이핑'이라고 한다.

// 인터페이스를 변수에 사용할 경우에도 덕 타이핑은 적용된다.
interface IPerson {
    name: string;
}

function sayHello(person: IPerson): void {
    console.log(`Hello ${person.name}`);
}

// const m3 = { name: 'Lee', age: 18 };
// sayHello(m3);
