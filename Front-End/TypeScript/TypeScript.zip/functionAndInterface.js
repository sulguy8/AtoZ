// 함수 인터페이스를 구현하는 함수는 인터페이스를 준수하여야 한다.
var SquareFunc = function (num) {
    return num * num;
};
console.log(SquareFunc(10));
