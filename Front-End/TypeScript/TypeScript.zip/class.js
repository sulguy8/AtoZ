var Person = /** @class */ (function () {
    function Person(name) {
        this.name = name;
    }
    Person.prototype.walk = function (num) {
        console.log(this.name + " " + num + " is walking.");
        return "hello";
    };
    return Person;
}());
var person = new Person('Lee');
person.walk(2);
