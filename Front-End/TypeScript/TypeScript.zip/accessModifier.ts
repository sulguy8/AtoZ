class Foo {
    public x: string;
    protected y: string;
    private z: string;

    constructor(x: string, y: string, z: string){
        // public, protected, private 접근 제한자 모두 클래스 내부에서 참조 가능
        this.x = x;
        this.y = y;
        this.z = z;
    }
}

const foo = new Foo('x','y','z');

// public 접근 제한자는 클래스 인스턴스를 통해 클래스 외부에서 참조 가능
console.log(foo.x);
// protectd, private 접근 제한자는 클래스 인스턴스를 통해 클래스 외부에서 참조할 수 없다.
// console.log(foo.y);
// console.log(foo.z);

class Bar extends Foo {
    constructor(x: string, y: string, z: String) {
        super(x, y, z = "not private"); // private는 참조할 수 없다.
        
    }
}