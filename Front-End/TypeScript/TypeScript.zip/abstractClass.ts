abstract class Animal {

    abstract makeSound(): void;

    move(): void {
        console.log('roaming the earth..');
    }

}

// 직접 인스턴스를 생성할 수 없다.
// new Animal // 오류뜸.

class Dog extends Animal {
    // 추상 클래스를 상속한 클래스는 추상 클래스의 추상 메소드를 반드시 구현해야한다.
    makeSound() {
        console.log('bowwow~~');
    }
}

const myDog = new Dog();
myDog.makeSound();
myDog.move();