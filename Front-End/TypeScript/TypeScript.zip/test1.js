function reverse3(items) {
    return items.reverse();
}
var arg2 = [1, "안녕?", 3, 4, 5];
// 인수에 의해 타입 매개변수가 결정된다.
var reversed2 = reverse3(arg2);
console.log(reversed2); // [5, 4, 3, 2, 1]
