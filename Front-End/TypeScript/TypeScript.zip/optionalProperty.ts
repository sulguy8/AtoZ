/* 
    인터페이스의 프로펀티는 반드시 구현되어야 하지만 선택적으로 필요한 경우도 있다.
    선택적 프로퍼티는 프로퍼티명 뒤에 ? 붙이고, 생략이 가능하다.
*/
interface UserInfo {
    username: string,
    password: string;
    age?: number,
    address?: string
}

const userInfo: UserInfo = {
    username: 'sulguy@naver.com',
    password: '123456'
}

console.log(userInfo);
