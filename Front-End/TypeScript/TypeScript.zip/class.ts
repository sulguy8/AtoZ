class Person {
    name: string;

    constructor(name: string) {
        this.name = name;
    }
    
    walk(num: number): string {
        console.log(`${this.name} ${num} is walking.`);
        return "hello";
    }
}

const person = new Person('Lee');
person.walk(2);