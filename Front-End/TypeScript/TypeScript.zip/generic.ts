// 정적타입의 언어인 경우 함수 또는 클래스를 정의하는 시점에서 매개변수와 반환값의 타입을 선언하여야 함.
// 타입스크립트도 마찬가지지만 함수 또는 클래스를 정의하는 시점에 매개변수나 반환값의 타입을 선언하기 어려운 경우가 생김

/* 오류생김;;
class Queue {
    protected data = []; // data: any[]
    
    push(item) {
        this.data.push(item);
    }

    pop() {
        return this.data.shift();
    }
}

const queue = new Queue();
queue.push(0);
queue.push('1');    // 의도하지 않은 실수!

console.log(queue.pop().toFixed()); // 0 
console.log(queue.pop().toFixed()); // Runtime Error
*/